// Symbian-specific file.

// INCLUDE FILES
#include "private/gcconfig.h"

extern "C" {

int winscw_data_start;

} /* extern "C" */
