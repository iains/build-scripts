
inline int chmod(char const * path, mode_t mode) {
    return 0;
}
